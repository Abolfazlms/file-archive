"""Metrics of report section 9.4 from sim logs.   python evaluate.py runs/A_none runs/B_none ...  [--plot out.png]"""
import csv, sys, os
import numpy as np

BINS = [(0, 10), (10, 30), (30, 60), (60, 100), (100, 160)]


def load(path):
    rows = list(csv.DictReader(open(os.path.join(path, "log.csv"))))
    return {k: np.array([r[k] for r in rows]) for k in rows[0]}


def metrics(d):
    f = lambda k: d[k].astype(float)
    th, eh = f("th"), f("eh")
    herr = np.hypot(f("eN") - f("tN"), f("eE") - f("tE"))
    m = {}
    for lo, hi in BINS:
        s = (th >= lo) & (th < hi)
        m[f"hor_rmse_{lo}-{hi}m"] = float(np.sqrt(np.mean(herr[s] ** 2))) if s.any() else np.nan
        m[f"h_rmse_{lo}-{hi}m"] = float(np.sqrt(np.mean((eh - th)[s] ** 2))) if s.any() else np.nan
    mk = f("marker") > 0
    m["marker_first_t"] = float(f("t")[mk][0]) if mk.any() else np.nan
    m["marker_last_alt"] = float(th[mk][-1]) if mk.any() else np.nan
    hold = d["phase"] == "HOLD"
    m["final_hor_err_hold"] = float(herr[hold].mean()) if hold.any() else float(herr[-1])
    m["max_alt"] = float(th.max())
    vis = d["phase"] == "VISION_CLIMB"
    if vis.any():
        h1, h2 = th[vis][0], th[vis][-1]
        m["drift_per_100m_vision"] = float((herr[vis][-1] - herr[vis][0]) / max(h2 - h1, 1) * 100)
        m["vision_ok_rate"] = float(f("tau_ok")[vis].mean())
        m["anchor_hits"] = int(f("anchor_ok")[vis].sum())
    m["latency_ms_mean"] = float(f("latency_ms").mean()); m["latency_ms_p95"] = float(np.percentile(f("latency_ms"), 95))
    m["phases"] = "->".join(dict.fromkeys(d["phase"]))
    return m, herr


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    plot = sys.argv[sys.argv.index("--plot") + 1] if "--plot" in sys.argv else None
    if plot:
        args = [a for a in args if a != plot]
    res = {}
    for a in args:
        d = load(a); res[a] = metrics(d) + (d,)
    keys = list(res[args[0]][0])
    print(f"{'run':28s}" + "".join(f"{os.path.basename(a)[:14]:>16s}" for a in args))
    for k in keys:
        print(f"{k:28s}" + "".join(f"{res[a][0][k]:>16.3f}" if isinstance(res[a][0][k], float) else f"{str(res[a][0][k])[:15]:>16s}" for a in args))
    if plot:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
        fig, ax = plt.subplots(1, 3, figsize=(15, 4.2))
        for a in args:
            m, herr, d = res[a]
            lab = os.path.basename(a)
            ax[0].plot(d["th"].astype(float), herr, label=lab); ax[1].plot(d["th"].astype(float), d["eh"].astype(float) - d["th"].astype(float), label=lab)
            ax[2].plot(d["t"].astype(float), d["th"].astype(float), label=lab)
        ax[0].set(xlabel="true altitude (m)", ylabel="horizontal error (m)", title="Horizontal error vs altitude"); ax[1].set(xlabel="true altitude (m)", ylabel="height error (m)", title="Height error")
        ax[2].set(xlabel="time (s)", ylabel="altitude (m)", title="Ascent profile")
        for x in ax: x.grid(alpha=.3)
        ax[0].legend(fontsize=8); plt.tight_layout(); plt.savefig(plot, dpi=130); print("plot ->", plot)
