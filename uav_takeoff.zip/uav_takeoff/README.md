# برخاست پهپاد با بینایی (بدون GPS) تا ۱۵۰ متر: کد شبیه‌سازی و پل Gazebo/PX4

پیاده‌سازی معماری `report_full_v2`:
- **فاز ۱:** پد ArUco تودرتو (مارکر ۱ m + چهار مارکر ۰٫۱ m داخل خانه‌های سفید آن) + PnP + ادغام وزنی.
- **فاز ۲ (نسخهٔ A):** EKF پانزده‌حالتهٔ Zhao با هموگرافی (`uavto/ekf_a.py`).
- **فاز ۲ (نسخهٔ B):** EKF کاهش‌یافته با attitude از autopilot، بایاس بارومتر، ارتفاع صفحه، keyframe و لنگر مارکر (`uavto/ekf_b.py`).
- **ماشین حالت:** `IDLE → OPEN_LOOP → MARKER_CLIMB → VISION_CLIMB → HOLD → DONE` و `DEGRADED` (`uavto/pipeline.py`).
- **شبیه‌ساز عددی** (`sim/`)، **ارزیابی** (`evaluate.py`) و **پل ROS2/MAVROS** برای Gazebo (`gazebo/`).

## مرحلهٔ ۱: نصب
```bash
python3 -m venv .venv && source .venv/bin/activate      # ویندوز: .venv\Scripts\activate
pip install -r requirements.txt                          # numpy scipy opencv-python>=4.7 matplotlib
```

## مرحلهٔ ۲: اجرای شبیه‌سازی عددی (بدون Gazebo)
هر اجرا حدود ۱ تا ۲ دقیقه روی لپ‌تاپ طول می‌کشد.
```bash
python -m sim.run_sim --estimator B --altimeter none    --out runs/B_none
python -m sim.run_sim --estimator B --altimeter laser40 --out runs/B_laser40
python -m sim.run_sim --estimator B --altimeter long150 --out runs/B_long150
python -m sim.run_sim --estimator A --altimeter none    --out runs/A_none
```
گزینه‌ها:
- `--control truth|estimate`: تثبیت جانبی با حقیقت (برای مقایسهٔ منصفانهٔ تخمین‌گرها) یا با تخمین (حلقه‌بسته).
- `--full-res`: دوربین ۱۹۲۰×۱۰۸۰ به‌جای ۹۶۰×۵۴۰.
- `--no-buildings`: بدون ساختمان.
- `--wind`، `--seed`، `--target`، `--climb-speed`، `--hold-time`.

## مرحلهٔ ۳: ارزیابی و نمودار
```bash
python evaluate.py runs/A_none runs/B_none runs/B_laser40 runs/B_long150 --plot runs/compare.png
```
خروجی شامل خطای افقی و ارتفاع در بازه‌های ارتفاعی، آخرین ارتفاع دیده شدن مارکر، drift به‌ازای ۱۰۰ m، نرخ موفقیت بینایی و latency است.

## مرحلهٔ ۴: Gazebo + PX4 (اجرا نشده در محیط نویسنده؛ مراحل را بررسی کن)
1. PX4-Autopilot و ROS2 (Humble یا Jazzy) و MAVROS را نصب کن و یک بار `make px4_sitl gz_x500` را اجرا کن تا سالم بودنش را ببینی.
2. پد را بساز: `python gazebo/make_pad_texture.py --out ~/gz_models/pad`. بعد `export GZ_SIM_RESOURCE_PATH=~/gz_models:$GZ_SIM_RESOURCE_PATH` و در world این را اضافه کن: `<include><uri>model://pad</uri></include>`. جهت بافت در Gazebo را بررسی نکرده‌ام. اگر در ۱ تا ۲ متری هیچ مارکری decode نشد، با `--flip-x` یا `--flip-y` یا `--rot90 1` دوباره بساز.
3. مدل پهپاد با دوربین رو به پایین (در PX4 معمولاً `gz_x500_mono_cam_down`) را اجرا کن. در SDF دوربین را روی **۱۹۲۰×۱۰۸۰ و hfov = 1.0996 rad** (۶۳°) بگذار. دنیا را با ساختمان‌ها و ارتفاع کافی (۱۵۰ m) بساز.
4. تصویر دوربین را به ROS ببر: `ros2 run ros_gz_bridge parameter_bridge /camera@sensor_msgs/msg/Image[gz.msgs.Image`. اسم topic را با `gz topic -l` ببین.
5. `ros2 launch mavros px4.launch fcu_url:=udp://:14540@127.0.0.1:14557`
6. در ترمینال دیگر:
   `python gazebo/ros2_node.py --ros-args -p image_topic:=/camera -p altimeter:=laser40 -p estimator:=B`
   (برای `range_topic` و `pressure_topic` اسم واقعی topicها را بگذار).
7. نود از لحظهٔ شروع، setpoint سرعت می‌فرستد. پهپاد را arm کن و به OFFBOARD ببر. ماشین حالت خودش بالا می‌رود و در ۱۵۰ m می‌ایستد. لاگ در `ros2_run.csv` است.
8. **در اولین اجراها GPS را در PX4 روشن بگذار** (فقط برای پایداری بدنه و حقیقت زمینی؛ پایپ‌لاین از GPS استفاده نمی‌کند). بعد از اطمینان، GPS را حذف کن و با `-p publish_vision:=true` تخمین را به EKF2 بده.

## پارامترهای باز (`uavto/config.py`)
بخش ۹٫۶ گزارش هنوز این‌ها را نامشخص گذاشته و در کد پارامتر هستند:
- نوع و برد آلتیمتر (`ALT_PRESETS`).
- FOV (افقی یا قطری؟).
- رفتار هنگام از دست رفتن بینایی (`degraded_policy`: `hover` یا `descend`).
- نرخ IMU (۱۰ Hz).
- حداقل ارتفاع شروع بینایی نسبی (`h_vis_min`).

## نتایج شبیه‌ساز (seed=0، ۱۵۰ m، باد ۳ m/s تقریبی، ۱۴ ساختمان، دوربین ۹۶۰×۵۴۰)
| اجرا | خطای افقی هنگام HOLD (m) | drift بینایی (m به‌ازای ۱۰۰ m) |
|---|---|---|
| A بدون آلتیمتر | 5.8 | 3.5 |
| A laser40 | 8.3 | 3.4 |
| A long150 | 12.6 | 6.1 |
| **B بدون آلتیمتر** | **4.2** | **2.1** |
| **B laser40** | **2.7** | **1.0** |
| **B long150** | **3.1** | **1.3** |

- مارکر بزرگ تا حدود ۲۵ m (در ۹۶۰ px) برای PnP قابل‌اعتماد است. دیده شدن در ۱۹۲۰ px تقریباً دو برابر می‌شود.
- **خطای ارتفاع ۱ تا ۱٫۸ m در ۱۵۰ m** عمدتاً از خطای مقیاس ۱٪ بارومتر در شبیه‌ساز است. آلتیمتر آن را کامل اصلاح نمی‌کند، چون بارومتر و آلتیمتر نمی‌توانند «بایاس بارومتر» را از «ارتفاع صفحهٔ زیر پهپاد» جدا کنند.
- در اجرای حلقه‌بسته با seed=3 (`--control estimate`) خطای B با laser40 برابر ۶٫۰ m و A بدون آلتیمتر برابر ۳٫۹ m شد. هر ردیف جدول یک seed است. برای نتیجهٔ آماری باید چندین seed اجرا کنی (`--seed 0..9`).
- زمان هر tick روی لپ‌تاپ کند با چند اجرای هم‌زمان حدود ۱۰۰ ms بود. روی CPU بدون بار کمتر می‌شود، ولی بودجهٔ ۱۰ Hz را روی سخت‌افزار هدف اندازه بگیر.

## نقشهٔ فایل‌ها
```
uavto/geometry.py    چارچوب‌ها و چرخش‌ها        uavto/marker.py   پد، تشخیص، PnP، ادغام
uavto/frontend.py    KLT، حل‌کنندهٔ tau، SIFT      uavto/ekf_a.py    EKF پانزده‌حالته (Zhao)
uavto/ekf_b.py       EKF کاهش‌یافته + کلون        uavto/pipeline.py پایپ‌لاین + ماشین حالت + فرمان
sim/world.py         دنیای مصنوعی (پد+ساختمان)    sim/vehicle.py    دینامیک + باد
sim/sensors.py       IMU/بارومتر/آلتیمتر         sim/run_sim.py    حلقهٔ شبیه‌سازی
evaluate.py          معیارها و نمودار             gazebo/           پل ROS2 و ساخت پد
```

## محدودیت‌های شناخته‌شده
- آشکارساز «لکه» برای دیدن پد در بیش از ۲۵ m پیاده نشده. بعد از رفتن مارکر، لنگر فقط با تطبیق SIFT keyframe کار می‌کند.
- پل Gazebo/ROS2 اجرا نشده و فقط syntax-check شده.
- دنیای شبیه‌ساز مصنوعی است و بافت آن فراکتالی است. روی تصاویر هوایی واقعی (برف، آب، سایه) نتایج بدتر می‌شود.
