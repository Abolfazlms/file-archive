"""Synthetic aerial world rendered through a pinhole camera.

Ground = procedural urban-like texture (parcels, roads, multi-octave noise) kept as an image pyramid;
pad = the real nested ArUco pad at 1 mm/px; buildings = flat roofs at height H drawn as separate planes (painter's order).
Every plane is rendered with one homography, choosing the pyramid level that matches the ground resolution (no aliasing).
"""
import cv2
import numpy as np
from uavto.geometry import R_BC


def _noise_texture(n, rng):
    img = np.zeros((n, n), np.float32)
    for k in range(1, 9):                                  # feature size 2^k px
        m = max(8, n >> k)
        o = rng.standard_normal((m, m)).astype(np.float32)
        img += cv2.resize(o, (n, n), interpolation=cv2.INTER_CUBIC) * (2.0 ** (-0.55 * k)) * 3
    return img


def _make_ground(n, gsd, rng):
    img = _noise_texture(n, rng)
    img = (img - img.mean()) / (img.std() + 1e-6) * 22 + 118
    canvas = np.zeros((n, n), np.float32)
    for _ in range(500):                                   # parcels
        w, h = rng.integers(int(4 / gsd), int(40 / gsd), 2)
        x, y = rng.integers(0, n - w), rng.integers(0, n - h)
        cv2.rectangle(canvas, (int(x), int(y)), (int(x + w), int(y + h)), float(rng.uniform(-35, 35)), -1)
    img += canvas
    for k in range(0, n, int(70 / gsd)):                   # roads
        off = int(rng.integers(-200, 200))
        cv2.line(img, (k, 0), (k + off, n), 62.0, int(5 / gsd))
        cv2.line(img, (0, k), (n, k + off), 62.0, int(5 / gsd))
    return np.clip(img, 15, 240).astype(np.uint8)


def _pyr(img, levels):
    out = [img]
    for _ in range(levels - 1):
        out.append(cv2.pyrDown(out[-1]))
    return out


class World:
    def __init__(self, pad_img, pad_px_per_m, seed=0, size_m=300.0, gsd=0.05, buildings=True):
        rng = np.random.default_rng(seed)
        self.gsd, self.n = gsd, int(size_m / gsd)
        self.X0 = self.Y0 = -size_m / 2
        self.ground = _pyr(_make_ground(self.n, gsd, rng), 6)
        self.pad = _pyr(pad_img, 10)
        self.pad_gsd = 1.0 / pad_px_per_m
        self.pad_half = pad_img.shape[0] / 2 / pad_px_per_m
        self.roofs = []
        if buildings:
            tries = 0
            while len(self.roofs) < 14 and tries < 400:
                tries += 1
                cN, cE = rng.uniform(-130, 130, 2)
                sN, sE = rng.uniform(15, 40, 2)
                if np.hypot(cN, cE) < 35 + max(sN, sE) / 2:
                    continue
                if any(abs(cN - r["cN"]) < (sN + r["sN"]) / 2 + 4 and abs(cE - r["cE"]) < (sE + r["sE"]) / 2 + 4 for r in self.roofs):
                    continue
                H = float(rng.uniform(8, 40))
                tex = _noise_texture(int(max(sN, sE) / gsd), rng)
                tex = (tex - tex.mean()) / (tex.std() + 1e-6) * 14 + float(rng.uniform(95, 190))
                th = int(0.6 / gsd)
                tex[:th, :] -= 35; tex[-th:, :] -= 35; tex[:, :th] -= 35; tex[:, -th:] -= 35   # parapet
                self.roofs.append(dict(cN=cN, cE=cE, sN=sN, sE=sE, H=H, pyr=_pyr(np.clip(tex, 10, 245).astype(np.uint8), 4),
                                       X0=cN - max(sN, sE) / 2, Y0=cE - max(sN, sE) / 2))
            self.roofs.sort(key=lambda r: r["H"])

    # ------------------------------------------------------------------
    def height_at(self, N, E):
        """Roof height above the pad plane at the nadir point (0 = ground)."""
        hmax = 0.0
        for r in self.roofs:
            if abs(N - r["cN"]) < r["sN"] / 2 and abs(E - r["cE"]) < r["sE"] / 2:
                hmax = max(hmax, r["H"])
        return hmax

    @staticmethod
    def _plane_H(K, R_cn, C, z_plane):
        M = np.column_stack([R_cn[:, 0], R_cn[:, 1], R_cn[:, 2] * z_plane - R_cn @ C])
        return K @ M                                        # (N, E, 1) -> pixel

    def _warp(self, pyr, g0, X0, Y0, Hp, depth, f, size, border=128, nsign=1):
        gsd_out = max(depth, 0.2) / f
        lvl = int(np.clip(np.floor(np.log2(max(gsd_out / g0, 1e-6))), 0, len(pyr) - 1))
        g = g0 * 2 ** lvl
        Mt = np.array([[0, nsign * g, X0], [g, 0, Y0], [0, 0, 1.0]])   # (col,row,1) -> (N,E,1)
        return cv2.warpPerspective(pyr[lvl], Hp @ Mt, size, flags=cv2.INTER_LINEAR,
                                   borderMode=cv2.BORDER_CONSTANT, borderValue=border)

    def _mask(self, Hp, N0, N1, E0, E1, size):
        pts = np.array([[N0, E0, 1], [N0, E1, 1], [N1, E1, 1], [N1, E0, 1]], float)
        q = (Hp @ pts.T).T
        if np.any(q[:, 2] <= 1e-6):
            return None
        q = q[:, :2] / q[:, 2:3]
        if q[:, 0].max() < 0 or q[:, 1].max() < 0 or q[:, 0].min() > size[0] or q[:, 1].min() > size[1]:
            return None
        m = np.zeros((size[1], size[0]), np.uint8)
        cv2.fillConvexPoly(m, np.round(q * 16).astype(np.int32), 255, shift=4)
        return m > 0

    def render(self, R_nb, pos_ned, cam, rng):
        K, size, f = cam.K, (cam.width, cam.height), cam.f
        R_cn = (R_nb @ R_BC).T
        C = np.asarray(pos_ned, float)
        alt = max(-C[2], 0.2)
        img = self._warp(self.ground, self.gsd, self.X0, self.Y0, self._plane_H(K, R_cn, C, 0.0), alt, f, size)
        Hp = self._plane_H(K, R_cn, C, 0.0)
        m = self._mask(Hp, -self.pad_half, self.pad_half, -self.pad_half, self.pad_half, size)
        if m is not None:
            w = self._warp(self.pad, self.pad_gsd, self.pad_half, -self.pad_half, Hp, alt, f, size, border=255, nsign=-1)
            img[m] = w[m]
        for r in self.roofs:
            depth = alt - r["H"]
            if depth < 1.0:
                continue
            Hr = self._plane_H(K, R_cn, C, -r["H"])
            side = max(r["sN"], r["sE"])
            m = self._mask(Hr, r["cN"] - r["sN"] / 2, r["cN"] + r["sN"] / 2, r["cE"] - r["sE"] / 2, r["cE"] + r["sE"] / 2, size)
            if m is None:
                continue
            w = self._warp(r["pyr"], self.gsd, r["X0"], r["Y0"], Hr, depth, f, size)
            img[m] = w[m]
        out = cv2.GaussianBlur(img, (0, 0), 0.6).astype(np.float32)
        out += rng.normal(0, 1.5, out.shape).astype(np.float32)
        return np.clip(out, 0, 255).astype(np.uint8)
