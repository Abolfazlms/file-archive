"""Point-mass quadrotor with a first-order velocity loop, wind-gust acceleration and acceleration-driven tilt."""
import numpy as np
from uavto.geometry import G, euler_to_R


class Vehicle:
    def __init__(self, h0, rng, wind_mean=(0.15, 0.1), gust_sigma=0.35, tau_v=0.6):
        self.p = np.array([0.0, 0.0, -h0])
        self.v = np.zeros(3)
        self.a = np.zeros(3)
        self.rng, self.tau_v = rng, tau_v
        self.wind_mean = np.array([wind_mean[0], wind_mean[1], 0.0])
        self.gust = np.zeros(3)
        self.gust_sigma = gust_sigma
        self.jit = np.zeros(2)
        self.psi = 0.0
        self.R_nb = np.eye(3)

    def step(self, dt, v_cmd_ned):
        tau_w = 3.0                                             # OU gust acceleration (correlation time 3 s)
        self.gust += (-self.gust / tau_w) * dt + self.gust_sigma * np.sqrt(2 * dt / tau_w) * self.rng.standard_normal(3) * [1, 1, 0.3]
        a = (v_cmd_ned - self.v) / self.tau_v + self.wind_mean + self.gust
        a = np.clip(a, -4.0, 4.0)
        self.p = self.p + self.v * dt + 0.5 * a * dt ** 2
        self.v = self.v + a * dt
        if self.p[2] > -0.1:                                    # ground contact
            self.p[2], self.v[2] = -0.1, min(self.v[2], 0.0)
        self.a = a
        self.jit += (-self.jit / 2.0) * dt + np.radians(0.6) * np.sqrt(2 * dt / 2.0) * self.rng.standard_normal(2)
        theta = np.clip(-a[0] / G, -0.4, 0.4) + self.jit[0]     # forward accel -> nose down
        phi = np.clip(a[1] / G, -0.4, 0.4) + self.jit[1]
        self.R_nb = euler_to_R(phi, theta, self.psi)
        return self.R_nb
