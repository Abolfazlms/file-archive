"""Simulated sensors: 10 Hz IMU, autopilot attitude, barometer, optional altimeter."""
import numpy as np
from uavto.geometry import G, expm_so3, logm_so3


class SimSensors:
    def __init__(self, cfg, rng):
        self.c, self.alt, self.rng = cfg.sens, cfg.alt, rng
        self.b_acc = rng.normal(0, self.c.acc_bias / 2, 3)
        self.b_gyro = rng.normal(0, self.c.gyro_bias / 2, 3)
        self.b_att = np.radians(self.c.att_bias_deg) * rng.standard_normal(3) * [1, 1, 0.5]
        self.b_baro = 0.0
        self.R_prev = None
        self.t_prev = None

    def measure(self, t, veh, world):
        c, rng = self.c, self.rng
        R = veh.R_nb
        dt = (t - self.t_prev) if self.t_prev is not None else None
        # gyro (body rate) from the true attitude change, accelerometer = specific force
        w = np.zeros(3) if self.R_prev is None else logm_so3(self.R_prev.T @ R) / dt
        f_b = R.T @ (veh.a - np.array([0, 0, G]))
        imu = dict(gyro=w + self.b_gyro + rng.normal(0, c.gyro_sigma, 3),
                   acc=f_b + self.b_acc + rng.normal(0, c.acc_sigma, 3))
        self.b_att += rng.normal(0, np.radians(0.02), 3) * [1, 1, 0.5]
        dR = expm_so3(self.b_att + rng.normal(0, 1, 3) * np.radians([c.att_noise_deg, c.att_noise_deg, c.att_yaw_noise_deg]))
        imu["R_nb"] = R @ dR
        # barometer
        if dt:
            self.b_baro += rng.normal(0, c.baro_bias_rw * np.sqrt(dt))
        h = -veh.p[2]
        baro = h * (1 + c.baro_scale_err) + self.b_baro + rng.normal(0, c.baro_sigma)
        # altimeter (distance to the surface below, slant along the body z axis)
        rng_m, d_true = None, h - world.height_at(veh.p[0], veh.p[1])
        if self.alt.enabled and rng.random() > self.alt.dropout:
            slant = d_true / max(R[2, 2], 0.5)
            if slant <= self.alt.max_range:
                rng_m = slant + rng.normal(0, self.alt.sigma0 + self.alt.sigma_rel * slant)
        self.R_prev, self.t_prev = R.copy(), t
        return imu, baro, rng_m, d_true
