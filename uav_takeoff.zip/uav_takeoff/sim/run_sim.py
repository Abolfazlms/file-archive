"""Closed-loop numerical simulation of the whole chain (marker phase -> hand-over -> vision phase -> 150 m).

  python -m sim.run_sim --estimator B --altimeter long150 --out runs/B_long150
Truth is used ONLY for logging (and for lateral hold when --control truth).
"""
import argparse, csv, os, sys, time
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from uavto import Config, Pipeline, PHASE_NAMES
from uavto.config import AltimeterCfg
from uavto.marker import PadDesign
from sim.world import World
from sim.vehicle import Vehicle
from sim.sensors import SimSensors


def run(args):
    cfg = Config()
    if args.full_res:
        cfg.cam.width, cfg.cam.height = 1920, 1080
    cfg.alt = AltimeterCfg.from_mode(args.altimeter)
    cfg.est.target_h = args.target
    cfg.est.v_vision = args.climb_speed
    cfg.est.hold_time = args.hold_time
    rng = np.random.default_rng(args.seed)
    pad = PadDesign()
    world = World(pad.render(1000), 1000, seed=args.seed + 1, buildings=not args.no_buildings)
    veh = Vehicle(cfg.sens.h0, rng, wind_mean=(args.wind, 0.6 * args.wind))
    sens = SimSensors(cfg, rng)
    pipe = Pipeline(cfg, args.estimator, seed=args.seed)
    dt = 1.0 / cfg.sens.rate_hz
    rows, v_cmd = [], np.zeros(3)
    img_rng = np.random.default_rng(args.seed + 2)
    t_wall = time.time()
    veh.step(dt, v_cmd)
    for k in range(int(args.max_time / dt)):
        t = k * dt
        imu, baro, rng_m, d_true = sens.measure(t, veh, world)
        gray = world.render(veh.R_nb, veh.p, cfg.cam, img_rng)
        out = pipe.step(t, imu, baro, rng_m, gray)
        vN, vE, vU = pipe.command()
        if args.control == "truth":                                     # lateral hold from truth (fair estimator comparison)
            vN, vE = np.clip(-cfg.est.kp_hold * veh.p[:2], -2, 2)
        e, inf = out["est"], out["info"]
        rows.append(dict(t=round(t, 2), phase=PHASE_NAMES[out["phase"]],
                         tN=veh.p[0], tE=veh.p[1], th=-veh.p[2], tvN=veh.v[0], tvE=veh.v[1], tvU=-veh.v[2], d_true=d_true,
                         eN=e["pN"], eE=e["pE"], eh=e["h"], evN=e["vN"], evE=e["vE"], evU=e["vh"], es=e["s"], eb=e["b"],
                         marker=int(inf["marker"]), n_markers=inf["n_markers"], marker_px=round(inf["marker_px"], 1),
                         tau_ok=int(inf["tau_ok"]), tau_inl=inf["tau_inl"], anchor_ok=int(inf["anchor_ok"]), kf=int(inf["kf"]),
                         alt_used=int(inf["alt_used"]), range_m=-1 if rng_m is None else round(rng_m, 3),
                         latency_ms=round(out["latency_ms"], 1)))
        veh.step(dt, np.array([vN, vE, -vU]))
        if k % 50 == 0:
            print(f"t={t:6.1f}s {PHASE_NAMES[out['phase']]:13s} h_true={-veh.p[2]:6.1f} h_est={e['h']:6.1f} "
                  f"pos_err={np.hypot(e['pN']-veh.p[0], e['pE']-veh.p[1]):6.2f} m  [{time.time()-t_wall:5.0f}s wall]", flush=True)
        if PHASE_NAMES[out["phase"]] == "DONE":
            break
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "log.csv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)
    print("saved", os.path.join(args.out, "log.csv"))
    return rows


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--estimator", choices=["A", "B"], default="B")
    ap.add_argument("--altimeter", choices=["none", "laser40", "long150"], default="none")
    ap.add_argument("--control", choices=["truth", "estimate"], default="truth")
    ap.add_argument("--target", type=float, default=150.0)
    ap.add_argument("--climb-speed", type=float, default=3.0)
    ap.add_argument("--hold-time", type=float, default=10.0)
    ap.add_argument("--max-time", type=float, default=160.0)
    ap.add_argument("--wind", type=float, default=0.15, help="mean wind acceleration (m/s^2)")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--no-buildings", action="store_true")
    ap.add_argument("--full-res", action="store_true")
    ap.add_argument("--out", default="runs/run")
    run(ap.parse_args())
