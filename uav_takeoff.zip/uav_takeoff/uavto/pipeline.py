"""Glue: marker phase -> hand-over -> relative-vision phase, finite state machine, commands.

The same Pipeline object is driven by the numerical simulator (sim/run_sim.py) and by the ROS2/MAVROS node (gazebo/ros2_node.py).
Inputs each tick (<= 10 Hz):  imu = dict(gyro, acc, R_nb),  baro altitude (m),  altimeter slant range (m or None),  gray image.
"""
import time
import numpy as np
from .geometry import R_BC, R_CB, R_to_euler, wrap
from .marker import PadDesign, MarkerDetector
from .frontend import KltTracker, AnchorMatcher, derotate, solve_tau, homography_body
from .ekf_a import EKFA
from .ekf_b import EKFB

IDLE, OPEN, MARKER, VISION, HOLD, DEGRADED, DONE = range(7)
PHASE_NAMES = ["IDLE", "OPEN_LOOP", "MARKER_CLIMB", "VISION_CLIMB", "HOLD", "DEGRADED", "DONE"]


class Pipeline:
    def __init__(self, cfg, estimator="B", seed=0):
        self.cfg, self.ec = cfg, cfg.est
        self.estimator = estimator
        self.K = cfg.cam.K
        self.pad = PadDesign()
        self.det = MarkerDetector(self.pad, self.K)
        self.trk = KltTracker(self.ec.max_features)
        self.matcher = AnchorMatcher()
        self.rng = np.random.default_rng(seed)
        self.ekf = None
        self.phase = IDLE
        self.t_prev = None
        self.baro_ref = 0.0
        self.marker_streak = self.marker_miss = 0
        self.t_marker_last = -1e9
        self.vis_bad = 0
        self.anchor = None
        self.t_anchor_try = -1e9
        self.kf_R = None
        self.kf_t = 0.0
        self.t_hold = 0.0
        self.last = {}

    # ------------------------------------------------------------------ helpers
    def _est(self):
        x = self.ekf.x
        if self.estimator == "B":
            return dict(pN=x[0], pE=x[1], vN=x[2], vE=x[3], h=x[4], vh=x[5], s=x[7], b=x[6])
        return dict(pN=x[0], pE=x[1], vN=x[3], vE=x[4], h=-x[2], vh=-x[5], s=0.0, b=0.0)

    def _init(self, t, imu, baro):
        h0 = self.cfg.sens.h0
        self.baro_ref = baro - h0                                      # barometer zeroed on the pad
        if self.estimator == "B":
            self.ekf = EKFB(self.ec, 0.0, 0.0, h0)
        else:
            self.ekf = EKFA(self.ec, np.array([0.0, 0.0, -h0]), imu["R_nb"])
        self.t_prev = t
        self.phase = OPEN

    def _sig_alt(self, r):
        a = self.cfg.alt
        return a.sigma0 + a.sigma_rel * r

    # ------------------------------------------------------------------ main step
    def step(self, t, imu, baro, rng_m, gray):
        t0 = time.perf_counter()
        R_nb = imu["R_nb"]
        if self.ekf is None:
            self._init(t, imu, baro)
        dt = t - self.t_prev
        self.t_prev = t
        info = dict(marker=False, n_markers=0, marker_px=0.0, tau_inl=0, tau_ok=False, anchor_ok=False, kf=False, alt_used=False)

        # 1) predict
        if dt > 0:
            if self.estimator == "B":
                self.ekf.predict(dt, R_nb, imu["acc"])
            else:
                self.ekf.predict(dt, imu["gyro"], imu["acc"])

        # 2) barometer / altimeter / yaw
        hb = baro - self.baro_ref
        if self.estimator == "B":
            self.ekf.update_baro(hb, self.ec.sigma_baro)
        else:
            self.ekf.update_height(hb, self.ec.sigma_baro)
            self.ekf.update_yaw(R_to_euler(R_nb)[2], np.radians(1.0))
        if rng_m is not None and self.cfg.alt.enabled:
            d = rng_m * R_nb[2, 2]                                    # slant -> vertical distance (cos roll * cos pitch)
            sg = self._sig_alt(rng_m)
            if self.estimator == "B":
                info["alt_used"] = self.ekf.update_altimeter(d, sg)
            else:
                info["alt_used"] = self.ekf.update_height(d, sg)       # A has no plane-height state: altimeter acts as height

        # 3) marker (phase 1)
        h_est = self._est()["h"]
        marker_on = self.phase <= MARKER or (t - self.t_marker_last) < 2.0
        mk = None
        if marker_on:
            mk = self.det.estimate(gray, R_nb @ R_BC)
            info.update(n_markers=mk["n"], marker_px=mk["max_px"])
        if mk is not None and mk["ok"]:
            info["marker"] = True
            self.t_marker_last = t
            self.marker_miss = 0
            self.marker_streak += 1
            C = mk["C"]
            if self.estimator == "B":
                self.ekf.update_marker(C, mk["sigma_xy"], mk["sigma_h"])
            else:
                self.ekf.update_marker(C, mk["sigma_xy"], mk["sigma_h"])
            if h_est > self.ec.h_vis_min and self.estimator == "B":    # keep the highest marker-anchored keyframe
                self.anchor = dict(img=gray.copy(), R=R_nb.copy(), p=np.array([C[0], C[1], -C[2]]), d=-C[2])
                self.matcher.set_anchor(self.anchor["img"])
        else:
            self.marker_streak = 0
            if marker_on:
                self.marker_miss += 1

        # 4) relative vision (phase 2)
        if self.phase >= MARKER and self.phase != DONE:
            if self.estimator == "B":
                self._vision_B(t, gray, R_nb, info)
            else:
                self._vision_A(t, gray, info)

        # 5) FSM
        self._fsm(t, info, mk)

        e = self._est()
        self.last = dict(est=e, phase=self.phase, info=info, latency_ms=(time.perf_counter() - t0) * 1e3)
        return self.last

    # ------------------------------------------------------------------ EKF-B vision
    def _new_keyframe(self, gray, R_nb, t):
        self.trk.start(gray)
        self.kf_R, self.kf_t = R_nb.copy(), t
        self.ekf.set_clone()

    def _vision_B(self, t, gray, R_nb, info):
        e = self._est()
        if e["h"] < self.ec.h_vis_min:
            return
        f = self.K[0, 0]
        if self.kf_R is None:
            self._new_keyframe(gray, R_nb, t)
            return
        self.trk.update(gray)
        p0, p1 = self.trk.pairs()
        ok = False
        if len(p0) >= 12:
            x0, x1 = derotate(p0, self.K, self.kf_R), derotate(p1, self.K, R_nb)
            res = solve_tau(x0, x1, self.ec.ransac_px / f, self.rng, self.ec.sigma_px / f)
            if res is not None:
                tau, cov, inl = res
                tau_n, cov_n = R_CB.T @ tau, R_CB.T @ cov @ R_CB
                cov_n = cov_n + np.eye(3) * 2 * self.ec.sigma_att_est ** 2      # autopilot attitude noise floor
                ok = self.ekf.update_relative(tau_n, cov_n)
                info.update(tau_ok=ok, tau_inl=int(inl.sum()))
        self.vis_bad = 0 if ok else self.vis_bad + 1
        disp = float(np.median(np.linalg.norm(p1 - p0, axis=1))) if len(p0) else 0.0
        if len(p0) < self.ec.kf_min_tracks or len(p0) < 0.5 * self.trk.n0 or disp > self.ec.kf_disp_px \
                or (t - self.kf_t) > self.ec.kf_max_age:
            self._new_keyframe(gray, R_nb, t)
            info["kf"] = True
        # anchor tie (only after the marker is gone)
        if self.anchor is not None and self.phase >= VISION and (t - self.t_anchor_try) >= self.ec.anchor_period:
            self.t_anchor_try = t
            d_cur = max(e["h"] - e["s"], 2.0)
            pr = self.matcher.match(gray, min(self.anchor["d"] / d_cur, 1.0))
            if pr is not None:
                x0, x1 = derotate(pr[0], self.K, self.anchor["R"]), derotate(pr[1], self.K, R_nb)
                res = solve_tau(x0, x1, 2 * self.ec.ransac_px / f, self.rng, self.ec.sigma_px / f)
                if res is not None and res[2].sum() >= self.ec.anchor_min_inl:
                    tau, cov, inl = res
                    tau_n, cov_n = R_CB.T @ tau, R_CB.T @ cov @ R_CB
                    cov_n = cov_n + np.eye(3) * 2 * self.ec.sigma_att_est ** 2
                    info["anchor_ok"] = self.ekf.update_anchor(tau_n, cov_n, self.anchor["p"], self.anchor["d"])

    # ------------------------------------------------------------------ EKF-A vision
    def _vision_A(self, t, gray, info):
        e = self._est()
        if e["h"] < self.ec.h_vis_min:
            self.ekf.reset_gbuf()
            self.trk.start(gray)
            return
        ok = False
        if self.trk.prev is not None and self.trk.alive is not None and len(self.trk.alive) > 0:
            self.trk.update(gray)
            p0, p1 = self.trk.pairs()
            r = homography_body(p0, p1, self.K)
            if r is not None:
                ok = self.ekf.update_homography(r[0])
                info.update(tau_ok=ok, tau_inl=r[1])
            else:
                self.ekf.reset_gbuf()
        self.vis_bad = 0 if ok else self.vis_bad + 1
        self.trk.start(gray)                                   # consecutive-frame homography (as in Zhao)

    # ------------------------------------------------------------------ FSM
    def _fsm(self, t, info, mk):
        e, c = self._est(), self.ec
        if self.phase == OPEN:
            if self.marker_streak >= 3:
                self.phase = MARKER
            elif e["h"] > c.open_loop_max_h:
                self.phase = DEGRADED                             # marker never acquired
        elif self.phase == MARKER:
            # hand-over height H1 from the pixel size of the big marker: side_px ~ f * 1 m / h  (not from a fixed altitude)
            h_ho = self.K[0, 0] * self.pad.side / c.px_handover
            if self.marker_miss >= c.marker_lost_frames or e["h"] > h_ho:
                self.phase = VISION
        elif self.phase == VISION:
            if e["h"] >= c.target_h:
                self.phase, self.t_hold = HOLD, t
            elif self.vis_bad > c.vis_bad_max and e["h"] > c.h_vis_min + 5:
                self.phase = DEGRADED
        elif self.phase == HOLD:
            if t - self.t_hold >= c.hold_time:
                self.phase = DONE
        elif self.phase == DEGRADED:
            if self.vis_bad == 0 and e["h"] > c.h_vis_min and e["h"] < c.target_h and self.marker_streak == 0 \
                    and self.anchor is not None:
                self.phase = VISION

    # ------------------------------------------------------------------ commands
    def command(self):
        """-> (v_north, v_east, v_up) velocity setpoint."""
        e, c = self._est(), self.ec
        vz = {IDLE: 0, OPEN: c.v_open, MARKER: c.v_marker, VISION: c.v_vision, HOLD: 0, DEGRADED: 0, DONE: 0}[self.phase]
        if self.phase == DEGRADED and c.degraded_policy == "descend":
            vz = -1.0
        v = -c.kp_hold * np.array([e["pN"], e["pE"]])
        if self.phase == DEGRADED:
            v = np.zeros(2)                                       # position estimate not trusted: just stop
        v = np.clip(v, -c.v_lat_max, c.v_lat_max)
        return float(v[0]), float(v[1]), float(vz)
