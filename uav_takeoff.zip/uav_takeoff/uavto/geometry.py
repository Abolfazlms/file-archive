"""Frames and rotation helpers.

Frames
  nav  : NED (x north, y east, z down), origin at the pad centre, ground plane z = 0.
  body : FRD (x forward, y right, z down).
  cam  : OpenCV (x right, y down, z forward).  Camera looks straight down, image top = body front.
Euler convention follows Zhao et al. (Eq. 2):  R_nb maps body -> nav.
"""
import numpy as np

G = 9.81
R_CB = np.array([[0.0, 1.0, 0.0], [-1.0, 0.0, 0.0], [0.0, 0.0, 1.0]])  # body -> cam
R_BC = R_CB.T.copy()                                                    # cam  -> body


def skew(w):
    return np.array([[0, -w[2], w[1]], [w[2], 0, -w[0]], [-w[1], w[0], 0.0]])


def expm_so3(w):
    th = float(np.linalg.norm(w))
    if th < 1e-9:
        return np.eye(3) + skew(w)
    K = skew(np.asarray(w) / th)
    return np.eye(3) + np.sin(th) * K + (1 - np.cos(th)) * K @ K


def logm_so3(R):
    c = np.clip((np.trace(R) - 1) / 2, -1, 1)
    th = float(np.arccos(c))
    if th < 1e-9:
        return np.zeros(3)
    return th / (2 * np.sin(th)) * np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]])


def euler_to_R(phi, theta, psi):
    cph, sph = np.cos(phi), np.sin(phi)
    cth, sth = np.cos(theta), np.sin(theta)
    cps, sps = np.cos(psi), np.sin(psi)
    return np.array([
        [cth * cps, sph * sth * cps - cph * sps, cph * sth * cps + sph * sps],
        [cth * sps, sph * sth * sps + cph * cps, cph * sth * sps - sph * cps],
        [-sth, sph * cth, cph * cth]])


def R_to_euler(R):
    theta = -np.arcsin(np.clip(R[2, 0], -1, 1))
    phi = np.arctan2(R[2, 1], R[2, 2])
    psi = np.arctan2(R[1, 0], R[0, 0])
    return np.array([phi, theta, psi])


def euler_rate_matrix(phi, theta):
    """L in  d(euler)/dt = L @ omega_body  (Zhao Eq. 2)."""
    cph, sph = np.cos(phi), np.sin(phi)
    tth, cth = np.tan(theta), np.cos(theta)
    return np.array([[1, sph * tth, cph * tth], [0, cph, -sph], [0, sph / cth, cph / cth]])


def wrap(a):
    return (a + np.pi) % (2 * np.pi) - np.pi


def numjac(f, x, eps=1e-6):
    """Central-difference Jacobian of vector function f at x."""
    x = np.asarray(x, float)
    y0 = np.asarray(f(x))
    J = np.zeros((y0.size, x.size))
    for i in range(x.size):
        d = np.zeros_like(x)
        d[i] = eps
        J[:, i] = (np.asarray(f(x + d)) - np.asarray(f(x - d))) / (2 * eps)
    return J
