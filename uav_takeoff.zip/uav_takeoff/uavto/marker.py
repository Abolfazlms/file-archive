"""Phase 1: nested multi-scale ArUco pad inside 1 m^2, detection, PnP and inverse-variance fusion.

Pad design (report 9.2, papers 40 / RArUco idea):
  * one big 1.0 m DICT_4X4_50 marker (long range),
  * four small 0.10 m markers placed inside the four *white* central cells of the big marker (close range / small blind zone).
    A small marker covers < 40 % of a cell, so the big marker's cell majority vote still reads white.
Pad frame = nav frame (x north, y east, z down) with origin at the pad centre.
"""
import cv2
import numpy as np
from .geometry import logm_so3

DICT_ID = cv2.aruco.DICT_4X4_50


def _dictionary():
    return cv2.aruco.getPredefinedDictionary(DICT_ID)


def _gen_marker(mid, px):
    if hasattr(cv2.aruco, "generateImageMarker"):
        return cv2.aruco.generateImageMarker(_dictionary(), mid, px, borderBits=1)
    return cv2.aruco.drawMarker(_dictionary(), mid, px)  # OpenCV < 4.7


def _cells(mid):
    img = _gen_marker(mid, 60)
    return np.array([[img[r * 10 + 5, c * 10 + 5] > 127 for c in range(6)] for r in range(6)])


class PadDesign:
    def __init__(self, side=1.0, small_side=0.10, margin=0.25):
        self.side, self.margin = side, margin
        big = None
        for mid in range(50):
            if _cells(mid)[2:4, 2:4].all():
                big = mid
                break
        if big is None:
            raise RuntimeError("no dictionary id with four white central cells")
        self.big_id = big
        cell = side / 6.0
        self.entries = {big: (side, 0.0, 0.0)}               # id -> (side, centre_N, centre_E)
        small_ids = [i for i in range(50) if i != big][:4]
        for sid, (r, c) in zip(small_ids, [(2, 2), (2, 3), (3, 2), (3, 3)]):
            self.entries[sid] = (small_side, (r - 2.5) * cell, (c - 2.5) * cell)

    def corners_world(self, mid):
        """4x3 NED corners (TL, TR, BR, BL of the marker image).  Seen from above with north up the pad reads un-mirrored:
        marker image-x -> east, marker image-y (down) -> south."""
        s, cN, cE = self.entries[mid]
        h = s / 2
        return np.array([[cN + h, cE - h, 0], [cN + h, cE + h, 0], [cN - h, cE + h, 0], [cN - h, cE - h, 0]], float)

    def render(self, px_per_m=1000):
        """Pad image, origin at the centre; pixel col <-> east, row <-> south (row grows southwards)."""
        P = int(round((self.side + 2 * self.margin) * px_per_m))
        img = np.full((P, P), 255, np.uint8)
        for mid, (s, cN, cE) in self.entries.items():
            sp = int(round(s * px_per_m))
            m = _gen_marker(mid, sp)
            r0 = int(round(P / 2 - (cN + s / 2) * px_per_m))
            c0 = int(round(P / 2 + (cE - s / 2) * px_per_m))
            img[r0:r0 + sp, c0:c0 + sp] = m
        return img


class MarkerDetector:
    def __init__(self, pad: PadDesign, K, scales=(1.0, 0.5, 0.25), min_px=30.0):
        self.pad, self.K, self.scales, self.min_px = pad, np.asarray(K, float), scales, min_px   # min_px: smallest marker side usable for PnP
        p = cv2.aruco.DetectorParameters()
        p.minMarkerPerimeterRate = 0.03
        p.adaptiveThreshWinSizeMax = 35
        p.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
        self.det = cv2.aruco.ArucoDetector(_dictionary(), p)

    def detect(self, gray):
        """Multi-scale detection (big markers fill the frame at low altitude -> use a pyramid)."""
        found = {}
        for s in self.scales:
            g = gray if s == 1.0 else cv2.resize(gray, None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
            corners, ids, _ = self.det.detectMarkers(g)
            if ids is None:
                continue
            for c, i in zip(corners, ids.ravel()):
                i = int(i)
                if i in self.pad.entries and i not in found:
                    found[i] = c.reshape(4, 2).astype(np.float64) / s
        return found

    def _single_pose(self, mid, corners, R_nc_prior):
        obj = self.pad.corners_world(mid)
        n, rvecs, tvecs, _ = cv2.solvePnPGeneric(obj, corners, self.K, None, flags=cv2.SOLVEPNP_IPPE)
        best = None
        for rv, tv in zip(rvecs, tvecs):
            Rcw, _ = cv2.Rodrigues(rv)                 # nav -> cam
            C = -Rcw.T @ tv.ravel()                    # camera position in nav
            if C[2] >= 0:                              # must be above the pad
                continue
            ang = np.linalg.norm(logm_so3(R_nc_prior.T @ Rcw.T))
            if best is None or ang < best[0]:
                best = (ang, rv, tv)
        if best is None:
            return None
        _, rv, tv = best
        rv, tv = cv2.solvePnPRefineLM(obj, corners, self.K, None, rv.copy(), tv.copy())
        Rcw, _ = cv2.Rodrigues(rv)
        return -Rcw.T @ tv.ravel(), best[0]

    def estimate(self, gray, R_nc_prior):
        """-> dict(ok, C(3, NED), sigma_xy, sigma_h, ids, max_px) ; the autopilot attitude disambiguates the planar-PnP flip."""
        found = self.detect(gray)
        out = dict(ok=False, ids=sorted(found), max_px=0.0, n=len(found))
        if not found:
            return out
        Cs, ws, sides = [], [], []
        for mid, c in found.items():
            r = self._single_pose(mid, c, R_nc_prior)
            if r is None:
                continue
            side_px = np.mean([np.linalg.norm(c[i] - c[(i + 1) % 4]) for i in range(4)])
            sides.append(side_px)
            if side_px < self.min_px:                                  # planar PnP is ambiguous / biased for tiny markers
                continue
            # ~0.5 px corner noise x3 depth factor, with a quadratic penalty below 60 px (measured in the sim)
            sigma = 1.5 * self.pad.entries[mid][0] / side_px * max(1.0, 60.0 / side_px) ** 2
            Cs.append(r[0]); ws.append(1.0 / max(sigma, 0.003) ** 2)
        out["max_px"] = max(sides) if sides else 0.0
        if not Cs:
            return out
        Cs, ws = np.array(Cs), np.array(ws)
        if len(Cs) >= 3:                                              # reject outliers around the median
            med = np.median(Cs, axis=0)
            keep = np.linalg.norm(Cs - med, axis=1) < max(0.3, 5 / np.sqrt(ws.max()))
            if keep.sum() >= 1:
                Cs, ws = Cs[keep], ws[keep]
        w = ws / ws.sum()                                             # paper 40 Eq.16: inverse-variance weights
        C = (w[:, None] * Cs).sum(0)
        s = 1.0 / np.sqrt(ws.sum())
        out.update(ok=True, C=C, sigma_xy=max(s, 0.01), sigma_h=max(2 * s, 0.02), max_px=max(sides))
        return out
