"""All tunable parameters in one place.  Items marked (OPEN) are still unknown in the report (section 9.6)."""
from dataclasses import dataclass, field
import math
import numpy as np


@dataclass
class CameraCfg:
    width: int = 960            # (OPEN) report assumes 1080p; sim default is half-res for speed (--full-res => 1920x1080)
    height: int = 540
    hfov_deg: float = 63.0      # horizontal FOV (OPEN: horizontal or diagonal?)

    @property
    def f(self):
        return (self.width / 2) / math.tan(math.radians(self.hfov_deg) / 2)

    @property
    def K(self):
        return np.array([[self.f, 0, self.width / 2], [0, self.f, self.height / 2], [0, 0, 1.0]])


ALT_PRESETS = {  # (OPEN) altimeter type / range / rate / accuracy are not decided yet
    "none": dict(max_range=0.0, sigma0=0.0, sigma_rel=0.0),
    "laser40": dict(max_range=40.0, sigma0=0.05, sigma_rel=0.005),
    "long150": dict(max_range=200.0, sigma0=0.15, sigma_rel=0.01),
}


@dataclass
class AltimeterCfg:
    mode: str = "none"
    max_range: float = 0.0
    sigma0: float = 0.0
    sigma_rel: float = 0.0
    dropout: float = 0.02

    @classmethod
    def from_mode(cls, mode, **over):
        if mode not in ALT_PRESETS:
            raise ValueError(f"altimeter mode must be one of {list(ALT_PRESETS)}")
        d = dict(ALT_PRESETS[mode])
        d.update(over)
        return cls(mode=mode, **d)

    @property
    def enabled(self):
        return self.mode != "none" and self.max_range > 0


@dataclass
class SensorCfg:                       # simulated sensors (values follow Zhao 2015 Table 1 where available)
    rate_hz: float = 10.0              # IMU / baro / altimeter / vision tick (IMU <= 10 Hz constraint)
    acc_sigma: float = 0.05
    acc_bias: float = 0.03 * 9.81
    gyro_sigma: float = 0.02
    gyro_bias: float = math.radians(0.5)
    att_noise_deg: float = 0.2         # autopilot attitude noise per sample (roll/pitch)
    att_yaw_noise_deg: float = 0.5
    att_bias_deg: float = 0.3          # slowly varying attitude bias
    baro_sigma: float = 0.5
    baro_bias_rw: float = 0.05         # m / sqrt(s)
    baro_scale_err: float = 0.01       # 1 % altitude scale error
    h0: float = 0.3                    # initial camera height above the pad (m)


@dataclass
class EstCfg:
    # --- estimator noise
    sigma_acc_proc: float = 0.6        # unmodelled acceleration noise used in EKF-B (m/s^2)
    sigma_baro: float = 0.6
    sigma_att_est: float = 0.004       # rad, attitude noise per sample assumed in vision covariance (B)
    sigma_px: float = 0.7              # feature localisation noise (px)
    ransac_px: float = 2.0
    sigma_H: float = 0.01              # per-entry homography noise (EKF-A)
    gate_p: float = 0.999
    # --- vision front end
    h_vis_min: float = 8.0             # start relative vision above this altitude (m)
    kf_disp_px: float = 30.0           # new keyframe when median displacement exceeds this
    kf_max_age: float = 6.0            # ... or older than this (s)
    kf_min_tracks: int = 25
    max_features: int = 400
    # --- anchor (keyframe tied to marker)
    anchor_period: float = 1.0
    anchor_min_inl: int = 25
    # --- finite state machine
    v_open: float = 0.5                # open-loop climb until the marker is seen (m/s)
    open_loop_max_h: float = 4.0
    v_marker: float = 1.5
    v_vision: float = 3.0
    px_handover: float = 34.0          # hand over when the largest marker is below this many pixels
    marker_lost_frames: int = 5
    target_h: float = 150.0
    hold_time: float = 10.0
    vis_bad_max: int = 30              # frames of failed vision before DEGRADED
    degraded_policy: str = "hover"     # (OPEN) behaviour on vision loss: 'hover' | 'descend'
    kp_hold: float = 0.4
    v_lat_max: float = 2.0


@dataclass
class Config:
    cam: CameraCfg = field(default_factory=CameraCfg)
    alt: AltimeterCfg = field(default_factory=AltimeterCfg)
    sens: SensorCfg = field(default_factory=SensorCfg)
    est: EstCfg = field(default_factory=EstCfg)
