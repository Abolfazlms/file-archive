"""EKF-A: reproduction of the 15-state homography EKF of Zhao et al. (J. Intell. Robot. Syst. 2015).

State  x = [p(3) v(3) euler(3) b_a(3) b_w(3)]  in NED.  IMU drives the process model, the 3x3 homography (vec, 9 values),
compass(yaw)/barometer/altimeter/marker are measurements.  Jacobians are numerical, so the model equations stay readable.
Homography model (Eq. 9-18):  H = R + T N^T / d ,  R ~ exp(-[w]x Tv),  T ~ -R_bn v Tv,  N ~ R^T R_bn e3,  d ~ -(p_z - v_z Tv).
"""
import numpy as np
from scipy.stats import chi2
from .geometry import G, euler_to_R, R_to_euler, euler_rate_matrix, expm_so3, numjac, wrap

E3 = np.array([0.0, 0.0, 1.0])


class EKFA:
    def __init__(self, cfg, p0, R_nb0):
        self.cfg = cfg
        self.x = np.zeros(15)
        self.x[0:3] = p0
        self.x[6:9] = R_to_euler(R_nb0)
        self.P = np.diag([0.1] * 3 + [0.2] * 3 + [np.radians(0.5)] * 3 + [0.3] * 3 + [0.02] * 3) ** 2
        self.gbuf = []
        self.last_chi2 = 0.0

    # ---------------- process model
    @staticmethod
    def f(x, gyro, acc, dt):
        p, v, rho, ba, bw = x[0:3], x[3:6], x[6:9], x[9:12], x[12:15]
        R = euler_to_R(*rho)
        a = R @ (acc + ba) + G * E3
        xn = x.copy()
        xn[0:3] = p + v * dt + 0.5 * a * dt ** 2
        xn[3:6] = v + a * dt
        xn[6:9] = rho + euler_rate_matrix(rho[0], rho[1]) @ (gyro + bw) * dt
        return xn

    def predict(self, dt, gyro, acc):
        F = numjac(lambda x: self.f(x, gyro, acc, dt), self.x)
        self.x = self.f(self.x, gyro, acc, dt)
        sa, sw = 0.4, 0.03                                   # inflated: IMU is only 10 Hz (zero-order hold error)
        Q = np.diag([1e-4] * 3 + [(sa * dt) ** 2] * 3 + [(sw * dt) ** 2] * 3 + [(1e-3 * dt) ** 2] * 3 + [(1e-4 * dt) ** 2] * 3)
        self.P = F @ self.P @ F.T + Q
        self.gbuf.append((dt, np.asarray(gyro, float).copy()))

    # ---------------- generic update
    def update(self, z, h, Rm, angle_idx=()):
        z = np.atleast_1d(z)
        y = z - h(self.x)
        for i in angle_idx:
            y[i] = wrap(y[i])
        H = numjac(h, self.x)
        S = H @ self.P @ H.T + Rm
        d2 = float(y @ np.linalg.solve(S, y))
        self.last_chi2 = d2
        if d2 > chi2.ppf(self.cfg.gate_p, len(z)):          # innovation gating (spike filter, Zhao Sec. 2.4)
            return False
        K = self.P @ H.T @ np.linalg.inv(S)
        self.x = self.x + K @ y
        I = np.eye(15)
        self.P = (I - K @ H) @ self.P @ (I - K @ H).T + K @ Rm @ K.T
        return True

    def update_height(self, d, sigma):                      # barometer or altimeter: z = -p_z
        return self.update(d, lambda x: np.array([-x[2]]), np.array([[sigma ** 2]]))

    def update_yaw(self, psi, sigma):
        return self.update(psi, lambda x: np.array([x[8]]), np.array([[sigma ** 2]]), angle_idx=(0,))

    def update_marker(self, C, sxy, sh):
        return self.update(C, lambda x: x[0:3].copy(), np.diag([sxy ** 2, sxy ** 2, sh ** 2]))

    # ---------------- homography
    def _hmodel(self, x):
        rho, bw, p, v = x[6:9], x[12:15], x[0:3], x[3:6]
        Rbn = euler_to_R(*rho).T
        R = np.eye(3)
        Tv = 0.0
        for dt, w in self.gbuf:
            R = expm_so3(-(w + bw) * dt) @ R
            Tv += dt
        T = -Rbn @ v * Tv
        N = R.T @ Rbn @ E3
        d = max(-(p[2] - v[2] * Tv), 0.5)
        return (R + np.outer(T, N) / d).flatten("F")

    def update_homography(self, Hb):
        ok = False
        if self.gbuf:
            ok = self.update(Hb.flatten("F"), self._hmodel, np.eye(9) * self.cfg.sigma_H ** 2)
        self.gbuf = []
        return ok

    def reset_gbuf(self):
        self.gbuf = []
