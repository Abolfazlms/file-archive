"""EKF-B: reduced filter (report 8.4 version B).  Attitude is an INPUT (autopilot EKF), so the IMU is used only for translation.

State  x = [pN, pE, vN, vE, h, vh, b, s]      h  = altitude above the pad plane (m, up), vh = climb rate
       b  = barometer bias,  s = height of the dominant ground plane above the pad plane  ->  plane distance d = h - s
Clone  c = [pN_k, pE_k, h_k, s_k]               (stochastic cloning of the current keyframe: relative-motion measurements)

Vision measurement (tau = -dp/d, in nav axes):   tau = [ -(pN-pN_k)/d_k , -(pE-pE_k)/d_k , (h-h_k)/d_k ] ,  d_k = h_k - s_k
The vertical component is the image-divergence cue: a second, independent link between climb rate and barometer.
"""
import numpy as np
from scipy.stats import chi2
from .geometry import G, numjac

NB = 8
IH, IS, IB = 4, 7, 6


class EKFB:
    def __init__(self, cfg, pN, pE, h0):
        self.cfg = cfg
        self.x = np.array([pN, pE, 0, 0, h0, 0, 0, 0.0])
        self.P = np.diag([0.05, 0.05, 0.1, 0.1, 0.05, 0.1, 0.05, 0.05]) ** 2
        self.has_clone = False
        self.last_chi2 = 0.0

    # ---------------- process
    def predict(self, dt, R_nb, f_b):
        a_n = R_nb @ f_b + np.array([0, 0, G])             # NED acceleration from specific force
        a = np.array([a_n[0], a_n[1], -a_n[2]])            # N, E, up
        n = len(self.x)
        F = np.eye(n)
        x = self.x
        for pi, vi, ai in ((0, 2, 0), (1, 3, 1), (4, 5, 2)):
            x[pi] += x[vi] * dt + 0.5 * a[ai] * dt ** 2
            x[vi] += a[ai] * dt
            F[pi, vi] = dt
        q = self.cfg.sigma_acc_proc ** 2
        Q = np.zeros((n, n))
        for pi, vi in ((0, 2), (1, 3), (4, 5)):
            Q[pi, pi] = q * dt ** 3 / 3; Q[pi, vi] = Q[vi, pi] = q * dt ** 2 / 2; Q[vi, vi] = q * dt
        Q[IB, IB] = (0.05 ** 2) * dt                        # baro bias random walk
        Q[IS, IS] = (0.3 ** 2) * dt                         # plane-height random walk (roofs)
        self.P = F @ self.P @ F.T + Q

    # ---------------- cloning
    def drop_clone(self):
        if self.has_clone:
            self.x = self.x[:NB].copy()
            self.P = self.P[:NB, :NB].copy()
            self.has_clone = False

    def set_clone(self):
        self.drop_clone()
        idx = [0, 1, IH, IS]
        J = np.zeros((4, NB))
        for r, c in enumerate(idx):
            J[r, c] = 1
        P = self.P
        self.P = np.block([[P, P @ J.T], [J @ P, J @ P @ J.T]])
        self.x = np.concatenate([self.x, self.x[idx]])
        self.has_clone = True

    # ---------------- update
    def update(self, z, h, Rm, gate_dof=None):
        z = np.atleast_1d(z)
        y = z - h(self.x)
        H = numjac(h, self.x)
        S = H @ self.P @ H.T + Rm
        d2 = float(y @ np.linalg.solve(S, y))
        self.last_chi2 = d2
        if d2 > chi2.ppf(self.cfg.gate_p, len(z)):
            return False
        K = self.P @ H.T @ np.linalg.inv(S)
        self.x = self.x + K @ y
        I = np.eye(len(self.x))
        self.P = (I - K @ H) @ self.P @ (I - K @ H).T + K @ Rm @ K.T
        return True

    def update_baro(self, hb, sigma):
        return self.update(hb, lambda x: np.array([x[IH] + x[IB]]), np.array([[sigma ** 2]]))

    def update_altimeter(self, d, sigma):                  # d = slant range corrected for roll/pitch = distance to the plane below
        return self.update(d, lambda x: np.array([x[IH] - x[IS]]), np.array([[sigma ** 2]]))

    def update_marker(self, C_ned, sxy, sh):
        z = np.array([C_ned[0], C_ned[1], -C_ned[2]])      # N, E, altitude
        return self.update(z, lambda x: np.array([x[0], x[1], x[IH]]), np.diag([sxy ** 2, sxy ** 2, sh ** 2]))

    def update_relative(self, tau_nav, cov_nav):
        if not self.has_clone:
            return False

        def h(x):
            dk = max(x[10] - x[11], 1.0)
            return np.array([-(x[0] - x[8]) / dk, -(x[1] - x[9]) / dk, (x[IH] - x[10]) / dk])
        return self.update(tau_nav, h, cov_nav)

    def update_anchor(self, tau_nav, cov_nav, pA, dA):
        """Relative measurement against the (fixed, marker-anchored) keyframe: pA = [N, E, h]."""
        dA = max(dA, 1.0)

        def h(x):
            return np.array([-(x[0] - pA[0]) / dA, -(x[1] - pA[1]) / dA, (x[IH] - pA[2]) / dA])
        return self.update(tau_nav, h, cov_nav)
