"""Vision front end: KLT tracks (sparse optical flow), derotation, the 3-DoF 'tau' solver, homography, SIFT anchor matching.

Derotation (EKF-B): with the autopilot attitude both frames are rotated into a virtual nav-aligned camera whose optical axis
points down.  For a level ground plane at distance d the motion model is then
        x1 ~ (x0 + tau_xy) / (1 + tau_z),      tau = -dp_v / d      (dp_v = camera displacement in virtual-cam axes)
which is linear in tau:  tau_x - u1*tau_z = u1 - u0 ,  tau_y - v1*tau_z = v1 - v0   -> RANSAC + least squares.
Large scale changes (anchor matching across a big altitude gap) are handled by the same model through tau_z.
"""
import cv2
import numpy as np
from .geometry import R_CB, R_BC


def derotate(pix, K, R_nb):
    """pixels (N,2) -> normalised coordinates in the virtual nav-aligned camera."""
    f, cx, cy = K[0, 0], K[0, 2], K[1, 2]
    rays = np.column_stack([(pix[:, 0] - cx) / f, (pix[:, 1] - cy) / f, np.ones(len(pix))])
    T = R_CB @ R_nb @ R_BC
    r = rays @ T.T
    return r[:, :2] / r[:, 2:3]


class KltTracker:
    def __init__(self, max_features=400):
        self.maxf = max_features
        self.prev = None
        self.p_kf = self.p_cur = self.alive = None
        self.n0 = 0

    def start(self, gray):
        pts = cv2.goodFeaturesToTrack(gray, self.maxf, 0.01, 10)
        self.prev = gray
        if pts is None:
            self.p_kf = self.p_cur = np.zeros((0, 2), np.float32)
            self.alive = np.zeros(0, bool)
            self.n0 = 0
            return
        self.p_kf = pts.reshape(-1, 2).astype(np.float32)
        self.p_cur = self.p_kf.copy()
        self.alive = np.ones(len(self.p_kf), bool)
        self.n0 = len(self.p_kf)

    def update(self, gray):
        idx = np.where(self.alive)[0]
        if len(idx) == 0:
            self.prev = gray
            return
        crit = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01)
        p0 = self.p_cur[idx].reshape(-1, 1, 2)
        p1, st, _ = cv2.calcOpticalFlowPyrLK(self.prev, gray, p0, None, winSize=(21, 21), maxLevel=3, criteria=crit)
        pb, stb, _ = cv2.calcOpticalFlowPyrLK(gray, self.prev, p1, None, winSize=(21, 21), maxLevel=3, criteria=crit)
        ok = (st.ravel() == 1) & (stb.ravel() == 1) & (np.linalg.norm((pb - p0).reshape(-1, 2), axis=1) < 0.7)
        self.p_cur[idx[ok]] = p1.reshape(-1, 2)[ok]
        self.alive[idx[~ok]] = False
        self.prev = gray

    def pairs(self):
        a = self.alive
        return self.p_kf[a].astype(np.float64), self.p_cur[a].astype(np.float64)


def solve_tau(x0, x1, thr, rng, sigma_n, iters=80):
    """-> (tau(3), cov(3x3), inlier_mask) or None.  thr and sigma_n are in normalised units."""
    N = len(x0)
    if N < 10:
        return None

    def ls(idx):
        A = np.zeros((2 * len(idx), 3)); b = np.zeros(2 * len(idx))
        A[0::2, 0] = 1; A[0::2, 2] = -x1[idx, 0]; b[0::2] = x1[idx, 0] - x0[idx, 0]
        A[1::2, 1] = 1; A[1::2, 2] = -x1[idx, 1]; b[1::2] = x1[idx, 1] - x0[idx, 1]
        return A, b

    def resid(t):
        return np.linalg.norm((x0 + t[:2]) / (1 + t[2]) - x1, axis=1)

    best_c, best_in = 0, None
    for _ in range(iters):
        idx = rng.choice(N, 2, replace=False)
        A, b = ls(idx)
        t = np.linalg.lstsq(A, b, rcond=None)[0]
        if t[2] < -0.9 or t[2] > 40:
            continue
        inl = resid(t) < thr
        c = int(inl.sum())
        if c > best_c:
            best_c, best_in = c, inl
    if best_in is None or best_c < 10:
        return None
    inl = best_in
    for _ in range(2):                                   # refit and re-evaluate the inlier set
        A, b = ls(np.where(inl)[0])
        t = np.linalg.lstsq(A, b, rcond=None)[0]
        if t[2] < -0.9 or t[2] > 40:
            return None
        inl = resid(t) < thr
        if inl.sum() < 10:
            return None
    A, b = ls(np.where(inl)[0])
    t = np.linalg.lstsq(A, b, rcond=None)[0]
    r = resid(t)[inl]
    s = max(float(np.sqrt(np.mean(r ** 2))), sigma_n)
    cov = (s ** 2) * np.linalg.inv(A.T @ A)
    return t, cov, inl


def homography_body(p0, p1, K):
    """EKF-A measurement: homography between two frames expressed in body axes and normalised (2nd singular value = 1)."""
    if len(p0) < 12:
        return None
    H, m = cv2.findHomography(p0, p1, cv2.RANSAC, 2.0)
    if H is None:
        return None
    Hn = np.linalg.inv(K) @ H @ K
    Hb = R_BC @ Hn @ R_CB
    s = np.linalg.svd(Hb, compute_uv=False)[1]
    if s < 1e-6:
        return None
    Hb = Hb / s
    if np.linalg.det(Hb) < 0:
        Hb = -Hb
    return Hb, int(m.sum())


class AnchorMatcher:
    """SIFT matching between the anchor keyframe (taken while the marker was still decodable) and the current frame,
    after pre-scaling the anchor to the current ground resolution (multi-scale matching, report 8.4)."""

    def __init__(self):
        self.sift = cv2.SIFT_create(nfeatures=1200)
        self.bf = cv2.BFMatcher(cv2.NORM_L2)
        self.img = None
        self.cache = {}

    def set_anchor(self, gray):
        self.img = gray
        self.cache = {}

    def _anchor_feats(self, k):
        if k not in self.cache:
            g = self.img if k == 1.0 else cv2.resize(self.img, None, fx=k, fy=k, interpolation=cv2.INTER_AREA)
            kp, des = self.sift.detectAndCompute(g, None)
            self.cache[k] = (np.array([p.pt for p in kp], np.float64) / k if kp else np.zeros((0, 2)), des)
        return self.cache[k]

    def match(self, gray, d_ratio):
        """d_ratio = d_anchor / d_current (<= 1).  Returns (pix_anchor, pix_current) or None."""
        k = min([1.0, 0.5, 0.25, 0.125], key=lambda q: abs(np.log(q) - np.log(max(d_ratio, 0.1))))
        pa, da = self._anchor_feats(k)
        kp, dc = self.sift.detectAndCompute(gray, None)
        if da is None or dc is None or len(da) < 8 or len(dc) < 8:
            return None
        pc = np.array([p.pt for p in kp], np.float64)
        good = []
        for pair in self.bf.knnMatch(da, dc, k=2):
            if len(pair) == 2 and pair[0].distance < 0.8 * pair[1].distance:
                good.append(pair[0])
        if len(good) < 10:
            return None
        return pa[[m.queryIdx for m in good]], pc[[m.trainIdx for m in good]]
