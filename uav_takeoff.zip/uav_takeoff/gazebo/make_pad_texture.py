"""Writes the nested-ArUco pad (1 m marker + four 0.10 m markers) as a PNG + a Gazebo (gz-sim) model folder.
Usage: python gazebo/make_pad_texture.py --out gazebo/models/pad [--flip-x] [--flip-y] [--rot90 N]
Seen from ABOVE with the model's +y axis (= north in ENU world) pointing up the texture must read un-mirrored.
Gazebo's UV orientation is not verified here: if no marker decodes at 1-2 m, regenerate with --flip-x / --flip-y / --rot90."""
import sys, os, argparse
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import cv2, numpy as np
from uavto.marker import PadDesign

ap = argparse.ArgumentParser(); ap.add_argument("--out", default="gazebo/models/pad")
ap.add_argument("--flip-x", action="store_true"); ap.add_argument("--flip-y", action="store_true"); ap.add_argument("--rot90", type=int, default=0)
a = ap.parse_args()
pad = PadDesign(); img = pad.render(1000)
size_m = img.shape[0] / 1000
if a.flip_x: img = img[:, ::-1]
if a.flip_y: img = img[::-1, :]
img = np.ascontiguousarray(np.rot90(img, a.rot90))
tex = os.path.join(a.out, "materials", "textures"); os.makedirs(tex, exist_ok=True)
cv2.imwrite(os.path.join(tex, "pad.png"), img)
open(os.path.join(a.out, "model.config"), "w").write('<?xml version="1.0"?><model><name>pad</name><version>1.0</version><sdf version="1.9">model.sdf</sdf></model>')
open(os.path.join(a.out, "model.sdf"), "w").write(f"""<?xml version="1.0"?>
<sdf version="1.9"><model name="pad"><static>true</static><pose>0 0 0.005 0 0 0</pose><link name="link"><visual name="v">
<geometry><plane><normal>0 0 1</normal><size>{size_m} {size_m}</size></plane></geometry>
<material><diffuse>1 1 1 1</diffuse><pbr><metal><albedo_map>materials/textures/pad.png</albedo_map><metalness>0.0</metalness><roughness>1.0</roughness></metal></pbr></material>
</visual></link></model></sdf>""")
print("pad", size_m, "m square ->", a.out, " add it to the world:  <include><uri>model://pad</uri></include>  (GZ_SIM_RESOURCE_PATH must contain", os.path.dirname(a.out) or ".", ")")
