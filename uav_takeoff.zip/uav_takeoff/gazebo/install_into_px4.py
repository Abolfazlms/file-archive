"""One-shot setup of the Gazebo side.   python3 gazebo/install_into_px4.py --px4 ~/PX4-Autopilot [--flip-x --flip-y --rot90 N]

 1. writes models `pad` (nested ArUco, 1.5 m) and `ground_tex` (300 m textured ground; Gazebo's default ground has no texture, so
    feature tracking would fail) into  <px4>/Tools/simulation/gz/models
 2. writes world <px4>/Tools/simulation/gz/worlds/takeoff.sdf  (= default.sdf + the two models)
 3. patches the downward camera model (mono_cam) to the resolution / FOV used by the pipeline (backup .bak kept)
Run PX4 afterwards with:  PX4_GZ_WORLD=takeoff make px4_sitl gz_x500_mono_cam_down
"""
import sys, os, re, shutil, argparse
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import cv2, numpy as np
from uavto.marker import PadDesign
from sim.world import _make_ground

ap = argparse.ArgumentParser()
ap.add_argument("--px4", required=True)
ap.add_argument("--flip-x", action="store_true"); ap.add_argument("--flip-y", action="store_true"); ap.add_argument("--rot90", type=int, default=0)
ap.add_argument("--width", type=int, default=960); ap.add_argument("--height", type=int, default=540); ap.add_argument("--hfov", type=float, default=1.0996)
a = ap.parse_args()
gz = os.path.join(os.path.expanduser(a.px4), "Tools", "simulation", "gz")
models, worlds = os.path.join(gz, "models"), os.path.join(gz, "worlds")
assert os.path.isdir(models) and os.path.isdir(worlds), f"not a PX4 checkout: {gz}"


def write_model(name, png, size_m, z):
    d = os.path.join(models, name); tex = os.path.join(d, "materials", "textures"); os.makedirs(tex, exist_ok=True)
    cv2.imwrite(os.path.join(tex, name + ".png"), png)
    open(os.path.join(d, "model.config"), "w").write(f'<?xml version="1.0"?><model><name>{name}</name><version>1.0</version><sdf version="1.9">model.sdf</sdf></model>')
    open(os.path.join(d, "model.sdf"), "w").write(f"""<?xml version="1.0"?>
<sdf version="1.9"><model name="{name}"><static>true</static><pose>0 0 {z} 0 0 0</pose><link name="link"><visual name="v">
<geometry><plane><normal>0 0 1</normal><size>{size_m} {size_m}</size></plane></geometry>
<material><diffuse>1 1 1 1</diffuse><pbr><metal><albedo_map>materials/textures/{name}.png</albedo_map><metalness>0.0</metalness><roughness>1.0</roughness></metal></pbr></material>
</visual></link></model></sdf>""")


pad = PadDesign(); img = pad.render(1000); size = img.shape[0] / 1000
if a.flip_x: img = img[:, ::-1]
if a.flip_y: img = img[::-1, :]
write_model("pad", np.ascontiguousarray(np.rot90(img, a.rot90)), size, 0.005)
write_model("ground_tex", _make_ground(4096, 300.0 / 4096, np.random.default_rng(1)), 300.0, 0.002)

src = os.path.join(worlds, "default.sdf"); dst = os.path.join(worlds, "takeoff.sdf")
w = open(src).read()
assert "</world>" in w, "default.sdf has no </world>"
w = w.replace("</world>", '  <include><uri>model://ground_tex</uri></include>\n  <include><uri>model://pad</uri></include>\n</world>', 1)
open(dst, "w").write(w); print("world ->", dst)

cam = os.path.join(models, "mono_cam", "model.sdf")
if os.path.exists(cam):
    t = open(cam).read(); shutil.copy(cam, cam + ".bak")
    t = re.sub(r"<width>\s*\d+\s*</width>", f"<width>{a.width}</width>", t)
    t = re.sub(r"<height>\s*\d+\s*</height>", f"<height>{a.height}</height>", t)
    t = re.sub(r"<horizontal_fov>[^<]*</horizontal_fov>", f"<horizontal_fov>{a.hfov}</horizontal_fov>", t)
    open(cam, "w").write(t); print(f"camera -> {a.width}x{a.height}, hfov {a.hfov} rad  ({cam})")
else:
    print("!! mono_cam/model.sdf not found: set the camera width/height/horizontal_fov by hand in the downward-camera model")
