#!/usr/bin/env python3
"""ROS 2 + MAVROS bridge for PX4 SITL (Gazebo) / real vehicle.      *** NOT executed in the authoring sandbox ***

Feeds the SAME Pipeline used by sim/run_sim.py.  The pipeline never reads GPS: only camera, IMU/attitude, barometer, altimeter.
For the first SITL runs keep GPS enabled in PX4 (it only keeps the airframe stable and is used for ground-truth logging
via /mavros/local_position/pose); remove it later and feed our estimate with --publish-vision.

Frames: MAVROS publishes ENU/FLU; the pipeline uses NED/FRD (converted below).
Run:  ros2 run ... or  python3 gazebo/ros2_node.py --ros-args -p image_topic:=/camera -p range_topic:=/mavros/distance_sensor/lidar ...
"""
import sys, os, csv, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import cv2
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image, Imu, FluidPressure, Range
from geometry_msgs.msg import TwistStamped, PoseStamped
from uavto import Config, Pipeline, PHASE_NAMES
from uavto.config import AltimeterCfg
from uavto.geometry import R_to_euler

T_NED_ENU = np.array([[0, 1, 0], [1, 0, 0], [0, 0, -1.0]])
T_FLU_FRD = np.diag([1.0, -1.0, -1.0])


def quat_to_R(q):                                            # x, y, z, w -> rotation matrix
    x, y, z, w = q
    return np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                     [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                     [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])


def img_to_gray(m):
    """sensor_msgs/Image -> uint8 gray (no cv_bridge needed)."""
    ch = {"mono8": 1, "8UC1": 1, "rgb8": 3, "bgr8": 3, "rgba8": 4, "bgra8": 4}[m.encoding]
    a = np.frombuffer(m.data, np.uint8).reshape(m.height, m.step)[:, : m.width * ch].reshape(m.height, m.width, ch)
    if ch == 1:
        return np.ascontiguousarray(a[:, :, 0])
    code = {"rgb8": cv2.COLOR_RGB2GRAY, "bgr8": cv2.COLOR_BGR2GRAY, "rgba8": cv2.COLOR_RGBA2GRAY, "bgra8": cv2.COLOR_BGRA2GRAY}[m.encoding]
    return cv2.cvtColor(np.ascontiguousarray(a), code)


class TakeoffNode(Node):
    def __init__(self):
        super().__init__("vision_takeoff")
        P = self.declare_parameter
        P("estimator", "B"); P("altimeter", "none"); P("target_h", 150.0); P("h0", 0.3)
        P("image_topic", "/camera/image_raw"); P("imu_topic", "/mavros/imu/data")
        P("pressure_topic", "/mavros/imu/static_pressure"); P("range_topic", "/mavros/distance_sensor/rangefinder")
        P("width", 1920); P("height", 1080); P("hfov_deg", 63.0); P("log", "ros2_run.csv"); P("publish_vision", False)
        g = lambda n: self.get_parameter(n).value
        cfg = Config()
        cfg.cam.width, cfg.cam.height, cfg.cam.hfov_deg = g("width"), g("height"), g("hfov_deg")
        cfg.alt = AltimeterCfg.from_mode(g("altimeter"))
        cfg.est.target_h, cfg.sens.h0 = g("target_h"), g("h0")
        self.cfg, self.pipe = cfg, Pipeline(cfg, g("estimator"))
        self.img = self.imu = self.p_static = self.range = self.p0 = None
        self.truth = None
        self.create_subscription(Image, g("image_topic"), lambda m: setattr(self, "img", m), qos_profile_sensor_data)
        self.create_subscription(Imu, g("imu_topic"), lambda m: setattr(self, "imu", m), qos_profile_sensor_data)
        self.create_subscription(FluidPressure, g("pressure_topic"), self._on_p, qos_profile_sensor_data)
        self.create_subscription(Range, g("range_topic"), lambda m: setattr(self, "range", m.range), qos_profile_sensor_data)
        self.create_subscription(PoseStamped, "/mavros/local_position/pose", lambda m: setattr(self, "truth", m), 10)
        self.cmd = self.create_publisher(TwistStamped, "/mavros/setpoint_velocity/cmd_vel", 10)
        self.vis = self.create_publisher(PoseStamped, "/mavros/vision_pose/pose", 10) if g("publish_vision") else None
        self.fh = open(g("log"), "w", newline=""); self.w = None
        self.create_timer(1.0 / cfg.sens.rate_hz, self.tick)
        self.get_logger().info("waiting for image + imu + pressure ... then arm and switch to OFFBOARD (setpoints stream from now on)")

    def _on_p(self, m):
        self.p_static = m.fluid_pressure
        if self.p0 is None:
            self.p0 = m.fluid_pressure

    def tick(self):
        t = self.get_clock().now().nanoseconds * 1e-9
        out = TwistStamped(); out.header.stamp = self.get_clock().now().to_msg(); out.header.frame_id = "map"
        if self.img is None or self.imu is None or self.p_static is None:
            self.cmd.publish(out); return
        q = self.imu.orientation
        R_nb = T_NED_ENU @ quat_to_R([q.x, q.y, q.z, q.w]) @ T_FLU_FRD
        w, a = self.imu.angular_velocity, self.imu.linear_acceleration
        imu = dict(gyro=np.array([w.x, -w.y, -w.z]), acc=np.array([a.x, -a.y, -a.z]), R_nb=R_nb)
        baro = 44330.0 * (1.0 - (self.p_static / self.p0) ** 0.1903)          # relative altitude from static pressure
        gray = img_to_gray(self.img)
        if gray.shape[1] != self.cfg.cam.width:
            gray = cv2.resize(gray, (self.cfg.cam.width, self.cfg.cam.height), interpolation=cv2.INTER_AREA)
        rng, self.range = self.range, None
        res = self.pipe.step(t, imu, baro + self.cfg.sens.h0, rng, gray)
        vN, vE, vU = self.pipe.command()
        out.twist.linear.x, out.twist.linear.y, out.twist.linear.z = vE, vN, vU     # NED -> ENU
        self.cmd.publish(out)
        e = res["est"]
        if self.vis is not None:
            p = PoseStamped(); p.header = out.header; p.header.frame_id = "map"
            p.pose.position.x, p.pose.position.y, p.pose.position.z = e["pE"], e["pN"], e["h"]
            p.pose.orientation = self.imu.orientation
            self.vis.publish(p)
        row = dict(t=t, phase=PHASE_NAMES[res["phase"]], eN=e["pN"], eE=e["pE"], eh=e["h"], marker=int(res["info"]["marker"]),
                   marker_px=res["info"]["marker_px"], tau_ok=int(res["info"]["tau_ok"]), latency_ms=res["latency_ms"],
                   gN=self.truth.pose.position.y if self.truth else np.nan, gE=self.truth.pose.position.x if self.truth else np.nan,
                   gh=self.truth.pose.position.z if self.truth else np.nan)      # g* = autopilot/GPS pose, logging only
        if self.w is None:
            self.w = csv.DictWriter(self.fh, fieldnames=list(row)); self.w.writeheader()
        self.w.writerow(row); self.fh.flush()


def main():
    rclpy.init(); n = TakeoffNode()
    try:
        rclpy.spin(n)
    finally:
        n.fh.close(); rclpy.shutdown()


if __name__ == "__main__":
    main()
